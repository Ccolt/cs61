CS 61 Problem Set 2
===================

This is bomb #247.

It belongs to Ccolt (ccoltsimonds@college.harvard.edu).
